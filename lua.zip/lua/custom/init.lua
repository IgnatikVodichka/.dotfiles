vim.opt.colorcolumn = "80"
vim.opt.relativenumber = true

vim.keymap.set("i", "jj", "<ESC>", { silent = true }, { desc = 'Quick escape from insert mode'})

local api = vim.api

api.nvim_create_autocmd({ 'BufRead', 'BufReadPost' }, {
  callback = function()
    local row, column = unpack(api.nvim_buf_get_mark(0, '"'))
    local buf_line_count = api.nvim_buf_line_count(0)

    if row >= 1 and row <= buf_line_count then
      api.nvim_win_set_cursor(0, { row, column })
    end
  end,
})

local format_sync_grp = api.nvim_create_augroup("GoFormat", {})
api.nvim_create_autocmd("BufWritePre", {
   pattern = "*.go",
   callback = function()
    require('go.format').goimport()
   end,
  group = format_sync_grp,
})
